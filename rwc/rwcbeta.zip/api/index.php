<?php
// API request router
header('Content-Type: application/json');

// Log API requests
$log_file = __DIR__ . '/../logs/api_redirects.log';
$request_uri = $_SERVER['REQUEST_URI'];
$request_method = $_SERVER['REQUEST_METHOD'];
$query_string = $_SERVER['QUERY_STRING'] ?? '';
$remote_addr = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';

// Log the request
$log_entry = date('Y-m-d H:i:s') . " | $remote_addr | $request_method | $request_uri | $query_string | $user_agent\n";
file_put_contents($log_file, $log_entry, FILE_APPEND);

// Extract the endpoint from the request URI
$path = parse_url($request_uri, PHP_URL_PATH);
$endpoint = basename($path);

// If the request is directly to api/ or api/index.php, redirect to land_surface_stations.php
if ($endpoint === 'api' || $endpoint === 'index.php') {
    // Pass all query parameters to the land_surface_stations.php endpoint
    include 'land_surface_stations.php';
    exit;
}

// Otherwise handle specific endpoints
switch ($endpoint) {
    case 'land_surface':
    case 'land_surface_stations':
        include 'land_surface_stations.php';
        break;
    
    case 'upper_air':
    case 'upper_air_stations':
        include 'upper_air_stations.php';
        break;
    
    // Add other API endpoints as needed
    
    default:
        // Return an error for unknown endpoints
        http_response_code(404);
        echo json_encode([
            'status' => 'error',
            'message' => 'API endpoint not found',
            'endpoint' => $endpoint
        ]);
        break;
}
?> 