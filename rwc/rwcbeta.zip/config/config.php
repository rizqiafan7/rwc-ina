<?php
// config/config.php
define('SITE_TITLE', 'Indonesian Operational System Monitoring');
define('SUPPORT_PHONE', '192');

// Improved SITE_URL detection for both local and hosting environments
function detectSiteUrl() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || 
                (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) ? 'https' : 'http';
    
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
    $scriptName = isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '';
    
    // For PHP's built-in server
    if (php_sapi_name() === 'cli-server') {
        return $protocol . '://' . $host;
    }
    
    // Get the document root and script path
    $docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? $_SERVER['DOCUMENT_ROOT'] : '';
    $scriptPath = isset($_SERVER['SCRIPT_FILENAME']) ? $_SERVER['SCRIPT_FILENAME'] : '';
    
    // Calculate the relative path from document root
    $relativePath = '';
    if (!empty($docRoot) && !empty($scriptPath)) {
        $relativePath = str_replace($docRoot, '', dirname($scriptPath));
        $relativePath = str_replace('\\', '/', $relativePath); // Normalize for Windows
    } else {
        // Fallback to script name
        $relativePath = dirname($scriptName);
    }
    
    // Handle subfolder navigation
    $pathBasename = basename($relativePath);
    if (in_array($pathBasename, ['pages', 'includes', 'config', 'api', 'uploads', 'templates', 'modules', 'monitoring', 'land_surface', 'land_upper-air'])) {
        $relativePath = dirname($relativePath);
        // If we're in GBON subfolder, go up one more level
        if (basename(dirname($relativePath)) === 'gbon') {
            $relativePath = dirname(dirname($relativePath));
        }
    }
    
    // Normalize path - PENTING: Jangan kasih trailing slash
    $relativePath = rtrim($relativePath, '/\\');
    
    if ($relativePath === '' || $relativePath === '.' || $relativePath === '/') {
        $relativePath = '';
    }
    
    return $protocol . '://' . $host . $relativePath;
}

define('SITE_URL', detectSiteUrl());
define('BASE_PATH', realpath(dirname(__DIR__)));

$isDev = true; // Force development mode to show errors

if ($isDev) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

date_default_timezone_set('Asia/Jakarta');

// Session configuration
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    session_start();
}

// Improved asset function for both local and hosting environments
function asset($path = '') {
    // For PHP's built-in server
    if (php_sapi_name() === 'cli-server') {
        return '/assets/' . ltrim($path, '/');
    }
    
    $baseUrl = SITE_URL;
    
    // Handle GBON subfolder
    $currentUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    if (strpos($currentUri, '/gbon/') !== false) {
        $baseUrl = dirname(dirname($baseUrl));
    }
    
    // Check if we're on a hosting environment where the site is in a subdirectory
    $assetPath = $baseUrl . '/assets/' . ltrim($path, '/');
    
    return $assetPath;
}

// Improved URL function for both local and hosting environments
function url($path = '') {
    $baseUrl = SITE_URL;
    
    // Handle GBON subfolder - always return to root for main navigation items
    $currentUri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    if (strpos($currentUri, '/gbon/') !== false && 
        !strpos($path, 'gbon/') === 0 && 
        !strpos($path, 'pages/') === 0) {
        $baseUrl = dirname(dirname($baseUrl));
    }
    
    if (empty($path) || $path === 'index') {
        return $baseUrl . '/index.php';
    }
    
    $cleanPath = ltrim($path, '/');
    if (strpos($cleanPath, '.') === false) {
        $cleanPath .= '.php';
    }
    
    return $baseUrl . '/' . $cleanPath;
}

// Improved active page detection
function isActivePage($path) {
    $currentScript = basename($_SERVER['PHP_SELF'], '.php');
    $targetPath = str_replace('.php', '', ltrim($path, '/'));
    
    // Handle index page
    if (($targetPath === 'index' || $targetPath === '') && $currentScript === 'index') {
        return true;
    }
    
    // Handle pages in subfolder
    if (strpos($targetPath, 'pages/') === 0) {
        $targetPage = str_replace('pages/', '', $targetPath);
        return basename(dirname($_SERVER['PHP_SELF'])) === 'pages' && $currentScript === $targetPage;
    }
    
    return $currentScript === $targetPath;
}

// Debug function to help troubleshoot routing issues
function debugPath() {
    echo '<div style="background:#f8f9fa;border:1px solid #ddd;padding:10px;margin:10px 0;font-family:monospace;font-size:12px;">';
    echo '<strong>SITE_URL:</strong> ' . SITE_URL . '<br>';
    echo '<strong>REQUEST_URI:</strong> ' . $_SERVER['REQUEST_URI'] . '<br>';
    echo '<strong>SCRIPT_NAME:</strong> ' . $_SERVER['SCRIPT_NAME'] . '<br>';
    echo '<strong>DOCUMENT_ROOT:</strong> ' . $_SERVER['DOCUMENT_ROOT'] . '<br>';
    echo '<strong>SCRIPT_FILENAME:</strong> ' . $_SERVER['SCRIPT_FILENAME'] . '<br>';
    echo '<strong>PHP_SELF:</strong> ' . $_SERVER['PHP_SELF'] . '<br>';
    echo '</div>';
}

// Utility functions
function sanitize($input) {
    return is_array($input) ? array_map('sanitize', $input) : htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    header("Location: $url");
    exit();
}

// Debug function to help troubleshoot (for temporary use)
function debug($var, $exit = false) {
    echo '<pre>';
    print_r($var);
    echo '</pre>';
    if ($exit) exit;
}

// Ensure required directories exist
foreach (['logs', 'data'] as $dir) {
    $dirPath = BASE_PATH . '/' . $dir;
    if (!is_dir($dirPath)) {
        mkdir($dirPath, 0755, true);
    }
}
?>